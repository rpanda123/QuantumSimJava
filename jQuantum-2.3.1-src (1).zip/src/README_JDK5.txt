Hint for Developers under JDK 5 or under some OS (e.g., Mac OS X):

Add the library javaws.jar to
   
   /Library/Java/Home/lib/ext
 
For Mac OS X 10.5 and 10.6, this jar-library should be available under:
   
   /System/Library/Frameworks/JavaVM.framework/Versions/1.6/Home/lib/

For Linux-Systems with java-6-sun installed (e.g., Ubuntu) it could be under:

   /usr/lib/jvm/java-6-sun/jre/lib/
